# Atlas & Aperture

A geography-first travel photo journal. The homepage of each trip is an interactive 3D
Mapbox globe — pins mark each Moment, an animated route line connects them chronologically,
and clicking a pin opens a scrapbook drawer with photos, journal entries, and metadata.

## Stack

| Layer | Choice |
|---|---|
| Framework | Next.js 14 (App Router, TypeScript) |
| Styling / motion | Tailwind CSS + Framer Motion |
| Map | Mapbox GL JS |
| Content | Sanity.io (embedded Studio at `/studio`) |
| Media | Cloudinary (hosting, optimization, EXIF extraction) |
| Automation | `exifr` for GPS/EXIF, Mapbox reverse geocoding, photo clustering |

## Getting started

```bash
npm install
cp .env.example .env.local   # fill in real credentials — see below
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) for the public site, and
[http://localhost:3000/studio](http://localhost:3000/studio) for Sanity Studio.

## Environment variables

See `.env.example` for the full list. You'll need:

- **Sanity** — create a project at [sanity.io/manage](https://sanity.io/manage), then a
  write-scoped API token (Editor role) for `SANITY_API_WRITE_TOKEN`.
- **Mapbox** — an access token from [account.mapbox.com](https://account.mapbox.com). Use a
  domain-restricted `pk.*` token for `NEXT_PUBLIC_MAPBOX_TOKEN` and a separate unrestricted
  token for `MAPBOX_SERVER_TOKEN` (used server-side for reverse geocoding).
- **Cloudinary** — cloud name + API key/secret from your
  [Cloudinary console](https://console.cloudinary.com).
- **Admin auth** — pick any `ADMIN_USER` / `ADMIN_PASSWORD` for the `/admin` uploader
  (protected via Basic Auth in `middleware.ts`).
- **`SANITY_REVALIDATE_SECRET`** — any random string; must match the webhook secret you set
  up in Sanity (see below).

## Content model

- **Trip** (`sanity/schemas/trip.ts`) — a named journey with a date range, map style, and
  route colour.
- **Moment** (`sanity/schemas/moment.ts`) — a single pin: GPS coordinates, a media array,
  journal entry (Portable Text), weather, transport mode, and mood.

Photos are stored as Cloudinary assets (`cloudinaryImage` object schema), not Sanity's
native image type — see `lib/ingestion/processPhotoBatch.ts` for why.

## Importing photos

Two ways to turn a camera roll into draft Moments, both running the same pipeline
(`lib/ingestion/processPhotoBatch.ts`):

1. **Admin UI** — visit `/admin`, pick a trip, drag in up to 60 photos.
2. **CLI, for bigger batches** —
   ```bash
   npm run import-photos -- --trip=<sanityTripId> --dir=./photos-to-import
   ```

The pipeline extracts EXIF GPS/camera data, uploads to Cloudinary, clusters nearby photos
taken close in time into a single Moment, reverse-geocodes the cluster's centroid via
Mapbox, and creates a **draft** (unpublished) Moment document. Drafts are intentional —
titles and journal entries need a human pass before they go live. Review and publish them
in Sanity Studio at `/studio`.

Photos with no recoverable GPS data (after both the local EXIF pass and a Cloudinary
metadata fallback) are skipped and reported back for manual placement.

## On-demand revalidation

Publishing a Trip or Moment in Sanity Studio should update the live site without a full
rebuild. Set up a webhook in `manage.sanity.io` → your project → API → Webhooks:

| Field | Value |
|---|---|
| URL | `https://<your-domain>/api/revalidate` |
| Dataset | `production` |
| Trigger on | Create, Update, Delete |
| Filter | `_type in ["trip", "moment"]` |
| Secret | matches `SANITY_REVALIDATE_SECRET` |

Projection (resolves a Moment's parent Trip slug so editing a Moment revalidates the right page):

```groq
{
  "_type": _type,
  "slug": select(_type == "trip" => slug.current, null),
  "tripSlug": select(_type == "moment" => *[_id == ^.trip._ref][0].slug.current, null)
}
```

## Deploying

1. Push to GitHub, import into Vercel (Next.js preset auto-detected).
2. Add every variable from `.env.example` to the Vercel project settings.
3. In Sanity's CORS settings, allow your Vercel domain (with credentials, for `/studio`).
4. Point the webhook above at your production domain.
5. `/api/moments/ingest` declares `maxDuration = 120`. Vercel's Hobby plan caps functions at
   10s (60s with Fluid Compute). Enable Fluid Compute, upgrade to Pro, or keep admin-UI
   batches small and use the CLI script for large imports.

## Project structure

```
app/
├── page.tsx                    # homepage — list of published trips
├── trips/[slug]/                # per-trip 3D map page
├── admin/                       # photo import UI (Basic Auth protected)
├── studio/[[...tool]]/          # embedded Sanity Studio
└── api/
    ├── moments/ingest/          # photo batch ingestion endpoint
    └── revalidate/               # Sanity webhook receiver

components/
├── map/                         # Mapbox globe, pins, route line
└── drawer/                      # Scrapbook drawer, carousel, lightbox

lib/
├── exif.ts, cloudinary.ts, geocode.ts, cloudinaryUrl.ts
└── ingestion/                   # clustering + batch orchestration

sanity/
├── schemas/                     # Trip, Moment, and shared object schemas
└── lib/                         # read client, write client, GROQ queries

scripts/import-photos.ts         # CLI bulk importer
```
