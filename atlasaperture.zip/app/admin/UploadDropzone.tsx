"use client";

import { useState, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface TripOption {
  _id: string;
  title: string;
}
interface IngestionResult {
  momentsCreated: { draftId: string; title: string; photoCount: number }[];
  needsManualLocation: string[];
  errors: { filename: string; error: string }[];
}

export function UploadDropzone({ trips }: { trips: TripOption[] }) {
  const [tripId, setTripId] = useState(trips[0]?._id ?? "");
  const [files, setFiles] = useState<File[]>([]);
  const [isDragging, setDragging] = useState(false);
  const [status, setStatus] = useState<"idle" | "uploading" | "done" | "error">("idle");
  const [result, setResult] = useState<IngestionResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const addFiles = useCallback((incoming: FileList | null) => {
    if (!incoming) return;
    setFiles((prev) => [...prev, ...Array.from(incoming).filter((f) => f.type.startsWith("image/"))]);
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragging(false);
      addFiles(e.dataTransfer.files);
    },
    [addFiles],
  );

  const removeFile = (index: number) => setFiles((prev) => prev.filter((_, i) => i !== index));

  const handleSubmit = async () => {
    if (!tripId || !files.length) return;
    setStatus("uploading");
    setErrorMsg(null);

    const formData = new FormData();
    formData.set("tripId", tripId);
    files.forEach((f) => formData.append("files", f));

    try {
      const res = await fetch("/api/moments/ingest", { method: "POST", body: formData });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Upload failed");

      setResult(data as IngestionResult);
      setStatus("done");
      setFiles([]);
    } catch (err) {
      setErrorMsg((err as Error).message);
      setStatus("error");
    }
  };

  return (
    <div className="mt-8">
      <label className="block text-xs font-medium uppercase tracking-widest text-white/40">
        Trip
      </label>
      <select
        value={tripId}
        onChange={(e) => setTripId(e.target.value)}
        className="mt-2 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white"
      >
        {trips.map((t) => (
          <option key={t._id} value={t._id} className="bg-slate-900">
            {t.title}
          </option>
        ))}
      </select>

      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
        onClick={() => inputRef.current?.click()}
        className={`mt-6 flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed p-12 text-center transition ${
          isDragging ? "border-amber-400 bg-amber-400/5" : "border-white/10 bg-white/[0.02]"
        }`}
      >
        <span className="text-3xl">📸</span>
        <p className="mt-3 text-sm text-white/60">
          Drag photos here, or <span className="text-amber-400">browse</span>
        </p>
        <p className="mt-1 text-xs text-white/30">
          JPEG, PNG, HEIC — GPS data required for auto-placement
        </p>
        <input
          ref={inputRef}
          type="file"
          multiple
          accept="image/*"
          className="hidden"
          onChange={(e) => addFiles(e.target.files)}
        />
      </div>

      {files.length > 0 && (
        <div className="mt-4 grid grid-cols-6 gap-2">
          {files.map((file, i) => (
            <div key={i} className="group relative aspect-square overflow-hidden rounded-lg bg-white/5">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={URL.createObjectURL(file)}
                alt={file.name}
                className="h-full w-full object-cover"
              />
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  removeFile(i);
                }}
                className="absolute right-1 top-1 flex h-5 w-5 items-center justify-center rounded-full bg-black/60 text-[10px] text-white opacity-0 transition group-hover:opacity-100"
              >
                ✕
              </button>
            </div>
          ))}
        </div>
      )}

      <button
        onClick={handleSubmit}
        disabled={!files.length || !tripId || status === "uploading"}
        className="mt-6 w-full rounded-lg bg-amber-400 py-3 text-sm font-semibold text-slate-950 transition disabled:cursor-not-allowed disabled:opacity-30"
      >
        {status === "uploading"
          ? `Processing ${files.length} photo${files.length === 1 ? "" : "s"}…`
          : `Import ${files.length || ""} photo${files.length === 1 ? "" : "s"}`}
      </button>

      <AnimatePresence>
        {status === "done" && result && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8 space-y-4 rounded-2xl border border-white/10 bg-white/[0.02] p-5"
          >
            <p className="text-sm font-semibold text-white">
              ✅ Created {result.momentsCreated.length} draft Moment
              {result.momentsCreated.length === 1 ? "" : "s"}
            </p>
            <ul className="space-y-1 text-xs text-white/50">
              {result.momentsCreated.map((m) => (
                <li key={m.draftId}>
                  • {m.title} — {m.photoCount} photo{m.photoCount === 1 ? "" : "s"}
                </li>
              ))}
            </ul>

            {result.needsManualLocation.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-amber-400">
                  ⚠️ {result.needsManualLocation.length} photo(s) had no GPS — add manually in
                  Studio:
                </p>
                <ul className="mt-1 text-xs text-white/40">
                  {result.needsManualLocation.map((f) => (
                    <li key={f}>• {f}</li>
                  ))}
                </ul>
              </div>
            )}

            {result.errors.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-red-400">
                  ❌ {result.errors.length} error(s):
                </p>
                <ul className="mt-1 text-xs text-white/40">
                  {result.errors.map((e) => (
                    <li key={e.filename}>
                      • {e.filename}: {e.error}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <a
              href="/studio/structure"
              target="_blank"
              className="inline-block text-xs font-medium text-amber-400 underline underline-offset-2"
            >
              Review drafts in Sanity Studio →
            </a>
          </motion.div>
        )}

        {status === "error" && errorMsg && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-4 text-sm text-red-400"
          >
            ❌ {errorMsg}
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  );
}
