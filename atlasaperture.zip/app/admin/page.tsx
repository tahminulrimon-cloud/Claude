import { sanityFetch } from "@/sanity/lib/client";
import { UploadDropzone } from "./UploadDropzone";

interface TripOption {
  _id: string;
  title: string;
}

export default async function AdminPage() {
  const trips = await sanityFetch<TripOption[]>({
    query: `*[_type == "trip"] | order(startDate desc) { _id, title }`,
    tags: ["trips-index"],
  });

  return (
    <main className="min-h-screen bg-slate-950 px-6 py-12">
      <div className="mx-auto max-w-2xl">
        <h1 className="font-display text-2xl font-bold text-white">Import Photos</h1>
        <p className="mt-1 text-sm text-white/40">
          Drop a batch of geotagged photos — they&apos;ll be clustered into draft Moments for
          review.
        </p>

        {trips.length === 0 ? (
          <p className="mt-8 rounded-xl border border-dashed border-white/10 p-6 text-sm text-white/30">
            No trips exist yet. Create one in Sanity Studio first.
          </p>
        ) : (
          <UploadDropzone trips={trips} />
        )}
      </div>
    </main>
  );
}
