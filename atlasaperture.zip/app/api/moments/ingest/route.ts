import { NextRequest, NextResponse } from "next/server";
import { processPhotoBatch, type RawPhotoInput } from "@/lib/ingestion/processPhotoBatch";

export const runtime = "nodejs"; // exifr + cloudinary SDK need Node, not Edge
export const maxDuration = 120; // batches can take a while — bump on your host if needed

const MAX_FILES = 60;

export async function POST(req: NextRequest) {
  const formData = await req.formData();

  const tripId = formData.get("tripId");
  if (typeof tripId !== "string" || !tripId) {
    return NextResponse.json({ error: "tripId is required" }, { status: 400 });
  }

  const fileEntries = formData.getAll("files") as File[];
  if (!fileEntries.length) {
    return NextResponse.json({ error: "No files uploaded" }, { status: 400 });
  }
  if (fileEntries.length > MAX_FILES) {
    return NextResponse.json(
      { error: `Too many files. Max ${MAX_FILES} per batch — use the CLI script for larger imports.` },
      { status: 400 },
    );
  }

  const photos: RawPhotoInput[] = await Promise.all(
    fileEntries.map(async (file) => ({
      filename: file.name,
      buffer: Buffer.from(await file.arrayBuffer()),
    })),
  );

  const radiusMeters = Number(formData.get("radiusMeters") ?? 150);
  const windowMinutes = Number(formData.get("windowMinutes") ?? 90);

  try {
    const result = await processPhotoBatch(photos, tripId, { radiusMeters, windowMinutes });
    return NextResponse.json(result, { status: 201 });
  } catch (err) {
    console.error("[ingest] Batch processing failed:", err);
    return NextResponse.json(
      { error: "Failed to process batch", detail: (err as Error).message },
      { status: 500 },
    );
  }
}
