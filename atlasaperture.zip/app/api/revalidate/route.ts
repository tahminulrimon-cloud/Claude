import { revalidateTag } from "next/cache";
import { NextRequest, NextResponse } from "next/server";
import { parseBody } from "next-sanity/webhook";

interface WebhookPayload {
  _type: "trip" | "moment";
  slug?: string; // present when _type === "trip"
  tripSlug?: string; // present when _type === "moment" (see GROQ projection in README)
}

export async function POST(req: NextRequest) {
  try {
    const { body, isValidSignature } = await parseBody<WebhookPayload>(
      req,
      process.env.SANITY_REVALIDATE_SECRET,
    );

    if (!isValidSignature) {
      return NextResponse.json({ message: "Invalid signature" }, { status: 401 });
    }
    if (!body?._type) {
      return NextResponse.json({ message: "Bad request" }, { status: 400 });
    }

    const slug = body._type === "trip" ? body.slug : body.tripSlug;
    if (!slug) {
      return NextResponse.json({ message: "No slug in payload — nothing to revalidate" });
    }

    revalidateTag(`trip:${slug}`);
    revalidateTag("trips-index");

    return NextResponse.json({ revalidated: true, tag: `trip:${slug}`, now: Date.now() });
  } catch (err) {
    console.error("[revalidate] Failed:", err);
    return NextResponse.json({ message: (err as Error).message }, { status: 500 });
  }
}
