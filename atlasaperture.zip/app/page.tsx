import Link from "next/link";
import { sanityFetch } from "@/sanity/lib/client";
import { ALL_TRIPS_QUERY } from "@/sanity/lib/queries";

interface TripListItem {
  _id: string;
  title: string;
  slug: string;
  tagline?: string;
  startDate: string;
  endDate: string;
  momentCount: number;
}

export default async function HomePage() {
  const trips = await sanityFetch<TripListItem[]>({
    query: ALL_TRIPS_QUERY,
    tags: ["trips-index"],
  });

  return (
    <main className="min-h-screen bg-slate-950 px-6 py-16">
      <div className="mx-auto max-w-4xl">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-amber-400">
          Atlas &amp; Aperture
        </p>
        <h1 className="mt-2 font-display text-4xl font-black text-white">
          Every journey, mapped.
        </h1>
        <p className="mt-3 max-w-lg text-white/50">
          Pick a trip to explore its interactive route map and scrapbook of moments.
        </p>

        {trips.length === 0 ? (
          <div className="mt-16 rounded-2xl border border-dashed border-white/10 p-12 text-center text-white/30">
            No published trips yet. Create one in{" "}
            <Link href="/studio" className="text-amber-400 underline">
              Sanity Studio
            </Link>
            .
          </div>
        ) : (
          <div className="mt-12 grid gap-4 sm:grid-cols-2">
            {trips.map((trip) => (
              <Link
                key={trip._id}
                href={`/trips/${trip.slug}`}
                className="group rounded-2xl border border-white/10 bg-white/[0.02] p-6 transition hover:border-amber-400/40 hover:bg-white/[0.04]"
              >
                <p className="text-xs uppercase tracking-widest text-white/40">
                  {trip.startDate} → {trip.endDate}
                </p>
                <h2 className="mt-2 font-display text-xl font-bold text-white group-hover:text-amber-400">
                  {trip.title}
                </h2>
                {trip.tagline && <p className="mt-1 text-sm text-white/50">{trip.tagline}</p>}
                <p className="mt-4 text-xs text-white/30">{trip.momentCount ?? 0} moments</p>
              </Link>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
