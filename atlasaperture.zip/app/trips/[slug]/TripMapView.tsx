"use client";

import dynamic from "next/dynamic";
import { useState, useCallback } from "react";
import { AnimatePresence } from "framer-motion";

import type { TripWithMoments, SanityMoment } from "@/types/sanity";
import { ScrapbookDrawer } from "@/components/drawer/ScrapbookDrawer";

const TripMap = dynamic(() => import("@/components/map/TripMap"), {
  ssr: false,
  loading: () => (
    <div className="flex h-full w-full items-center justify-center bg-slate-950">
      <span className="animate-pulse text-4xl">🌍</span>
    </div>
  ),
});

interface TripMapViewProps {
  trip: TripWithMoments;
}

export function TripMapView({ trip }: TripMapViewProps) {
  const [selectedMoment, setSelectedMoment] = useState<SanityMoment | null>(null);

  const handleMomentSelect = useCallback((moment: SanityMoment | null) => {
    setSelectedMoment(moment);
  }, []);

  const handleClose = useCallback(() => {
    setSelectedMoment(null);
  }, []);

  const drawerOpen = selectedMoment !== null;

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-slate-950">
      <TripMap
        trip={trip}
        selectedMoment={selectedMoment}
        onMomentSelect={handleMomentSelect}
        drawerOpen={drawerOpen}
      />

      <AnimatePresence mode="wait">
        {drawerOpen && selectedMoment && (
          <ScrapbookDrawer
            key={selectedMoment._id}
            moment={selectedMoment}
            tripColor={trip.routeColor ?? "#F4A261"}
            onClose={handleClose}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
