import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { sanityFetch } from "@/sanity/lib/client";
import { TRIP_WITH_MOMENTS_QUERY } from "@/sanity/lib/queries";
import type { TripWithMoments } from "@/types/sanity";
import { TripMapView } from "./TripMapView";

export async function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Promise<Metadata> {
  const trip = await sanityFetch<Pick<TripWithMoments, "title" | "tagline" | "coverImage"> | null>({
    query: `*[_type == "trip" && slug.current == $slug][0]{ title, tagline, coverImage }`,
    params: { slug: params.slug },
  });

  if (!trip) return {};

  return {
    title: `${trip.title} — Atlas & Aperture`,
    description: trip.tagline ?? `Explore the ${trip.title} trip on the map.`,
    openGraph: {
      images: trip.coverImage?.url ? [{ url: trip.coverImage.url }] : [],
    },
  };
}

export default async function TripPage({ params }: { params: { slug: string } }) {
  const trip = await sanityFetch<TripWithMoments | null>({
    query: TRIP_WITH_MOMENTS_QUERY,
    params: { slug: params.slug },
    tags: [`trip:${params.slug}`],
  });

  if (!trip) notFound();

  return (
    <main className="h-screen w-screen overflow-hidden">
      <TripMapView trip={trip} />
    </main>
  );
}
