"use client";

import { motion } from "framer-motion";

interface Props {
  count: number;
  activeIndex: number;
  onDotClick: (index: number) => void;
}

export function CarouselDots({ count, activeIndex, onDotClick }: Props) {
  if (count <= 1) return null;

  return (
    <div className="flex items-center justify-center gap-1.5 py-3">
      {Array.from({ length: count }).map((_, i) => (
        <button
          key={i}
          onClick={() => onDotClick(i)}
          aria-label={`Go to photo ${i + 1}`}
          className="relative flex h-4 w-4 items-center justify-center"
        >
          <motion.span
            className="block rounded-full"
            animate={{
              width: i === activeIndex ? 18 : 6,
              height: 6,
              backgroundColor: i === activeIndex ? "#F4A261" : "rgba(255,255,255,0.25)",
            }}
            transition={{ duration: 0.25, ease: "easeOut" }}
          />
        </button>
      ))}
    </div>
  );
}
