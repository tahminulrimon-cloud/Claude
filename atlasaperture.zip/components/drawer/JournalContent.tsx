"use client";

import { PortableText, type PortableTextComponents } from "@portabletext/react";
import type { PortableTextBlock } from "sanity";
import { motion } from "framer-motion";

interface Props {
  content: PortableTextBlock[];
}

const components: PortableTextComponents = {
  block: {
    normal: ({ children }) => (
      <p className="mb-4 text-sm leading-relaxed text-white/70">{children}</p>
    ),
    h3: ({ children }) => (
      <h3 className="mb-3 mt-6 font-display text-base font-bold text-white first:mt-0">
        {children}
      </h3>
    ),
    blockquote: ({ children }) => (
      <blockquote className="my-4 border-l-2 border-amber-400/50 pl-4 text-sm italic text-white/50">
        {children}
      </blockquote>
    ),
  },
  marks: {
    strong: ({ children }) => <strong className="font-semibold text-white">{children}</strong>,
    em: ({ children }) => <em className="italic">{children}</em>,
    underline: ({ children }) => (
      <span className="underline decoration-amber-400/60">{children}</span>
    ),
  },
};

export function JournalContent({ content }: Props) {
  if (!content?.length) {
    return <p className="text-sm italic text-white/30">No journal entry for this moment yet.</p>;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3, duration: 0.4 }}
    >
      <PortableText value={content} components={components} />
    </motion.div>
  );
}
