"use client";

import { motion } from "framer-motion";
import type { SanityMoment } from "@/types/sanity";
import { TRANSPORT_ICONS, WEATHER_ICONS } from "@/components/map/constants";

interface Props {
  moment: SanityMoment;
}

const chipVariants = {
  hidden: { opacity: 0, y: 8 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: 0.15 + i * 0.06, duration: 0.35, ease: "easeOut" as const },
  }),
};

export function MetadataChips({ moment }: Props) {
  const chips = [
    {
      icon: "📅",
      label: new Date(moment.capturedAt).toLocaleDateString("en-GB", {
        day: "numeric",
        month: "short",
        year: "numeric",
      }),
    },
    moment.weather && {
      icon: WEATHER_ICONS[moment.weather.condition] ?? "🌤️",
      label: `${moment.weather.temperatureCelsius}°C`,
    },
    moment.transportMode && {
      icon: TRANSPORT_ICONS[moment.transportMode] ?? "📍",
      label: moment.transportMode.replace("_", " "),
    },
    moment.mood && {
      icon: moodEmoji(moment.mood),
      label: moment.mood.replace("_", " "),
    },
  ].filter(Boolean) as { icon: string; label: string }[];

  return (
    <div className="flex flex-wrap gap-2 px-6">
      {chips.map((chip, i) => (
        <motion.div
          key={chip.label}
          custom={i}
          variants={chipVariants}
          initial="hidden"
          animate="visible"
          className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs capitalize text-white/70"
        >
          <span className="text-sm leading-none">{chip.icon}</span>
          {chip.label}
        </motion.div>
      ))}
    </div>
  );
}

function moodEmoji(mood: string): string {
  const map: Record<string, string> = {
    joyful: "😄",
    peaceful: "😌",
    in_awe: "🤩",
    tired: "😴",
    frustrated: "😤",
    emotional: "🥹",
  };
  return map[mood] ?? "💭";
}
