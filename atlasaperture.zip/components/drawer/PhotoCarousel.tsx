"use client";

import { useRef, useState, useCallback, useEffect } from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import type { MediaItem } from "@/types/sanity";
import { cloudinaryResizeUrl, cloudinaryBlurUrl } from "@/lib/cloudinaryUrl";
import { CarouselDots } from "./CarouselDots";
import { PhotoLightbox } from "./PhotoLightbox";

interface Props {
  media: MediaItem[];
}

export function PhotoCarousel({ media }: Props) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);

  const sorted = [...media].sort((a, b) => (b.isCover ? 1 : 0) - (a.isCover ? 1 : 0));

  const handleScroll = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    const slideWidth = el.clientWidth * 0.82 + 12;
    const index = Math.round(el.scrollLeft / slideWidth);
    setActiveIndex(Math.min(index, sorted.length - 1));
  }, [sorted.length]);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    el.addEventListener("scroll", handleScroll, { passive: true });
    return () => el.removeEventListener("scroll", handleScroll);
  }, [handleScroll]);

  const scrollToIndex = useCallback((index: number) => {
    const el = scrollRef.current;
    if (!el) return;
    const slideWidth = el.clientWidth * 0.82 + 12;
    el.scrollTo({ left: index * slideWidth, behavior: "smooth" });
    setActiveIndex(index);
  }, []);

  if (!sorted.length) return null;

  return (
    <div>
      <div
        ref={scrollRef}
        className="flex snap-x snap-mandatory gap-3 overflow-x-auto px-6 pb-1 [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden"
      >
        {sorted.map((item, i) => (
          <motion.button
            key={item._key}
            onClick={() => {
              setActiveIndex(i);
              setLightboxOpen(true);
            }}
            className="relative aspect-[4/5] w-[82%] flex-shrink-0 snap-center overflow-hidden rounded-2xl bg-slate-800"
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 + i * 0.07, duration: 0.4, ease: "easeOut" }}
            whileTap={{ scale: 0.97 }}
          >
            <Image
              src={cloudinaryResizeUrl(item.asset.url, 640)}
              alt={item.altText ?? item.caption ?? ""}
              fill
              sizes="(max-width: 420px) 82vw, 340px"
              className="object-cover"
              placeholder="blur"
              blurDataURL={cloudinaryBlurUrl(item.asset.url)}
            />

            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
            {item.caption && (
              <p className="absolute bottom-3 left-3 right-3 text-left text-xs font-medium text-white/90 line-clamp-2">
                {item.caption}
              </p>
            )}

            {item.mediaType !== "photo" && (
              <span className="absolute right-3 top-3 rounded-full bg-black/50 px-2 py-0.5 text-[10px] uppercase tracking-wide text-white/80">
                {item.mediaType}
              </span>
            )}

            <span className="absolute left-3 top-3 flex h-7 w-7 items-center justify-center rounded-full bg-black/40 text-xs text-white/80 backdrop-blur-sm">
              ⤢
            </span>
          </motion.button>
        ))}
      </div>

      <CarouselDots count={sorted.length} activeIndex={activeIndex} onDotClick={scrollToIndex} />

      {lightboxOpen && (
        <PhotoLightbox
          items={sorted}
          activeIndex={activeIndex}
          onClose={() => setLightboxOpen(false)}
          onNavigate={setActiveIndex}
        />
      )}
    </div>
  );
}
