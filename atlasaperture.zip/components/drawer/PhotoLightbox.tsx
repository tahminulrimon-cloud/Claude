"use client";

import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useCallback } from "react";
import Image from "next/image";
import type { MediaItem } from "@/types/sanity";
import { cloudinaryResizeUrl } from "@/lib/cloudinaryUrl";

interface Props {
  items: MediaItem[];
  activeIndex: number;
  onClose: () => void;
  onNavigate: (index: number) => void;
}

export function PhotoLightbox({ items, activeIndex, onClose, onNavigate }: Props) {
  const item = items[activeIndex];

  const goNext = useCallback(
    () => onNavigate((activeIndex + 1) % items.length),
    [activeIndex, items.length, onNavigate],
  );
  const goPrev = useCallback(
    () => onNavigate((activeIndex - 1 + items.length) % items.length),
    [activeIndex, items.length, onNavigate],
  );

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") goNext();
      if (e.key === "ArrowLeft") goPrev();
    };
    window.addEventListener("keydown", handler);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", handler);
      document.body.style.overflow = "";
    };
  }, [onClose, goNext, goPrev]);

  if (!item) return null;

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-xl"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
      >
        <button
          onClick={onClose}
          className="absolute right-6 top-6 flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/70 transition hover:text-white"
          aria-label="Close lightbox"
        >
          ✕
        </button>

        {items.length > 1 && (
          <>
            <button
              onClick={(e) => {
                e.stopPropagation();
                goPrev();
              }}
              className="absolute left-6 top-1/2 flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full border border-white/10 bg-white/5 text-2xl text-white/70 transition hover:text-white"
              aria-label="Previous photo"
            >
              ‹
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                goNext();
              }}
              className="absolute right-6 top-1/2 flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full border border-white/10 bg-white/5 text-2xl text-white/70 transition hover:text-white"
              aria-label="Next photo"
            >
              ›
            </button>
          </>
        )}

        <motion.div
          key={item._key}
          className="relative mx-auto flex max-h-[85vh] max-w-[85vw] flex-col items-center"
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          transition={{ duration: 0.25, ease: "easeOut" }}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="relative h-[75vh] w-[80vw] max-w-3xl">
            <Image
              src={cloudinaryResizeUrl(item.asset.url, 1600)}
              alt={item.altText ?? item.caption ?? ""}
              fill
              sizes="80vw"
              className="object-contain"
              priority
            />
          </div>

          {item.caption && (
            <p className="mt-4 max-w-lg text-center text-sm text-white/60">{item.caption}</p>
          )}

          {item.exifData && (item.exifData.aperture || item.exifData.iso) && (
            <div className="mt-2 flex gap-3 text-[11px] text-white/30">
              {item.exifData.model && <span>{item.exifData.model}</span>}
              {item.exifData.focalLength && <span>{item.exifData.focalLength}</span>}
              {item.exifData.aperture && <span>f/{item.exifData.aperture}</span>}
              {item.exifData.shutterSpeed && <span>{item.exifData.shutterSpeed}</span>}
              {item.exifData.iso && <span>ISO {item.exifData.iso}</span>}
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
