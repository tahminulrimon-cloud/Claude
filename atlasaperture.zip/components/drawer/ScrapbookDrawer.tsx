"use client";

import { motion, type PanInfo } from "framer-motion";
import type { SanityMoment } from "@/types/sanity";
import { PhotoCarousel } from "./PhotoCarousel";
import { MetadataChips } from "./MetadataChips";
import { JournalContent } from "./JournalContent";

interface Props {
  moment: SanityMoment;
  tripColor: string;
  onClose: () => void;
}

const drawerVariants = {
  hidden: { x: "100%", opacity: 0.6 },
  visible: {
    x: 0,
    opacity: 1,
    transition: { type: "spring" as const, stiffness: 320, damping: 34, mass: 0.9 },
  },
  exit: {
    x: "100%",
    opacity: 0,
    transition: { type: "spring" as const, stiffness: 320, damping: 38 },
  },
};

export function ScrapbookDrawer({ moment, tripColor, onClose }: Props) {
  const handleDragEnd = (_: unknown, info: PanInfo) => {
    if (info.offset.x > 120 || info.velocity.x > 500) onClose();
  };

  return (
    <motion.aside
      className="absolute inset-y-0 right-0 z-20 flex w-full max-w-[440px] flex-col overflow-hidden border-l border-white/10 bg-slate-950/95 shadow-[0_0_60px_rgba(0,0,0,0.5)] backdrop-blur-xl"
      variants={drawerVariants}
      initial="hidden"
      animate="visible"
      exit="exit"
      drag="x"
      dragConstraints={{ left: 0, right: 0 }}
      dragElastic={{ left: 0, right: 0.4 }}
      onDragEnd={handleDragEnd}
    >
      <div className="h-1 w-full flex-shrink-0" style={{ background: tripColor }} />

      <div className="flex-1 overflow-y-auto pb-8 [scrollbar-width:thin] [scrollbar-color:rgba(255,255,255,0.15)_transparent]">
        <div className="flex items-start justify-between px-6 pb-4 pt-6">
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.35 }}
          >
            {(moment.city || moment.country) && (
              <p className="text-xs font-medium uppercase tracking-widest text-amber-400/80">
                {[moment.city, moment.country].filter(Boolean).join(", ")}
              </p>
            )}
            <h2 className="mt-1 font-display text-2xl font-bold leading-tight text-white">
              {moment.title}
              {moment.isHighlight && <span className="ml-2 align-middle text-lg">⭐</span>}
            </h2>
            {moment.locationName && (
              <p className="mt-1 text-xs text-white/40">{moment.locationName}</p>
            )}
          </motion.div>

          <button
            onClick={onClose}
            className="ml-4 flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/50 transition hover:border-white/25 hover:text-white"
            aria-label="Close scrapbook"
          >
            ✕
          </button>
        </div>

        <MetadataChips moment={moment} />

        <div className="mt-6">
          <PhotoCarousel media={moment.media} />
        </div>

        <div className="mx-6 mt-6 border-t border-white/5" />

        <div className="px-6 pt-5">
          <h3 className="mb-3 text-[11px] font-semibold uppercase tracking-widest text-white/30">
            Journal
          </h3>
          <JournalContent content={moment.journalEntry ?? []} />
        </div>

        {moment.tags && moment.tags.length > 0 && (
          <div className="mt-2 flex flex-wrap gap-2 px-6">
            {moment.tags.map((tag) => (
              <span
                key={tag}
                className="rounded-full bg-white/5 px-2.5 py-1 text-[11px] text-white/40"
              >
                #{tag}
              </span>
            ))}
          </div>
        )}
      </div>

      <div className="pointer-events-none flex flex-shrink-0 justify-center border-t border-white/5 py-2 md:hidden">
        <span className="text-[10px] text-white/20">← swipe to close</span>
      </div>
    </motion.aside>
  );
}
