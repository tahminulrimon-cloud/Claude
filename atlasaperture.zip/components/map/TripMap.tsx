"use client";

import { useEffect, useRef, useState, useMemo } from "react";
import mapboxgl from "mapbox-gl";
import "mapbox-gl/dist/mapbox-gl.css";
import "./pin-marker.css";

import type { TripWithMoments, SanityMoment } from "@/types/sanity";
import { MAPBOX_STYLES } from "./constants";
import { createPinElement } from "./utils/createPinElement";
import { addRouteToMap, stopDashAnimation } from "./utils/addRouteToMap";
import { fitBoundsToMoments } from "./utils/fitBoundsToMoments";
import { MapLoadingOverlay } from "./MapLoadingOverlay";
import { AnimatePresence } from "framer-motion";

mapboxgl.accessToken = process.env.NEXT_PUBLIC_MAPBOX_TOKEN ?? "";

export interface TripMapProps {
  trip: TripWithMoments;
  selectedMoment: SanityMoment | null;
  onMomentSelect: (moment: SanityMoment | null) => void;
  drawerOpen: boolean;
}

export default function TripMap({
  trip,
  selectedMoment,
  onMomentSelect,
  drawerOpen,
}: TripMapProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<mapboxgl.Map | null>(null);
  const markersRef = useRef<Map<string, mapboxgl.Marker>>(new Map());
  const [mapLoaded, setMapLoaded] = useState(false);
  const [mapError, setMapError] = useState<string | null>(null);

  const styleUrl = useMemo(() => MAPBOX_STYLES[trip.mapStyle ?? "outdoors"], [trip.mapStyle]);

  // ── 1. Initialise the map ──────────────────────────────────────────────
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;
    if (!mapboxgl.accessToken) {
      setMapError("NEXT_PUBLIC_MAPBOX_TOKEN is not set.");
      return;
    }

    let map: mapboxgl.Map;
    try {
      map = new mapboxgl.Map({
        container: containerRef.current,
        style: styleUrl,
        center: [0, 20],
        zoom: 2,
        projection: { name: "globe" },
        antialias: true,
        logoPosition: "bottom-left",
      });
      mapRef.current = map;
    } catch {
      setMapError("Failed to initialise the map. Please check your Mapbox token.");
      return;
    }

    map.on("style.load", () => {
      map.setFog({
        color: "rgb(220, 230, 240)",
        "high-color": "rgb(36, 92, 223)",
        "horizon-blend": 0.02,
        "space-color": "rgb(11, 11, 25)",
        "star-intensity": 0.5,
      });
    });

    map.on("load", () => {
      if (trip.moments.length >= 2) {
        addRouteToMap(map, trip.moments, trip.routeColor ?? "#F4A261");
      }
      fitBoundsToMoments(map, trip.moments, { duration: 1600 });
      setMapLoaded(true);
    });

    map.on("error", (e) => {
      console.error("[TripMap] Mapbox error:", e);
      setMapError("Map failed to load. Try refreshing.");
    });

    map.addControl(new mapboxgl.NavigationControl({ visualizePitch: true }), "bottom-right");
    map.addControl(new mapboxgl.ScaleControl({ maxWidth: 120, unit: "metric" }), "bottom-left");
    map.addControl(new mapboxgl.FullscreenControl(), "bottom-right");

    map.on("click", () => onMomentSelect(null));

    return () => {
      stopDashAnimation();
      // Intentionally reads .current at unmount time, not a setup-time
      // snapshot: markers are populated by a separate effect after mount.
      // eslint-disable-next-line react-hooks/exhaustive-deps
      markersRef.current.forEach((m) => m.remove());
      // eslint-disable-next-line react-hooks/exhaustive-deps
      markersRef.current.clear();
      map.remove();
      mapRef.current = null;
      setMapLoaded(false);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── 2. Add / refresh markers when moments change ───────────────────────
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded) return;

    markersRef.current.forEach((marker) => marker.remove());
    markersRef.current.clear();

    const total = trip.moments.length;

    trip.moments.forEach((moment, index) => {
      const el = createPinElement(moment, index, total);
      el.style.animationDelay = `${index * 60}ms`;

      const marker = new mapboxgl.Marker({ element: el, anchor: "bottom", offset: [0, -4] })
        .setLngLat([moment.coordinates.lng, moment.coordinates.lat])
        .addTo(map);

      el.addEventListener("click", (e) => {
        e.stopPropagation();
        onMomentSelect(moment);
        map.flyTo({
          center: [moment.coordinates.lng, moment.coordinates.lat],
          zoom: Math.max(map.getZoom(), 11),
          duration: 1200,
          offset: drawerOpen ? [-200, 0] : [0, 0],
          essential: true,
        });
      });

      el.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          el.click();
        }
      });

      markersRef.current.set(moment._id, marker);
    });
  }, [mapLoaded, trip.moments, drawerOpen, onMomentSelect]);

  // ── 3. Toggle selected state on the correct pin ────────────────────────
  useEffect(() => {
    markersRef.current.forEach((marker, id) => {
      const el = marker.getElement();
      el.classList.toggle("pin--selected", id === selectedMoment?._id);
    });
  }, [selectedMoment]);

  // ── 4. Adjust map padding when the drawer opens / closes ──────────────
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded) return;

    map.easeTo({
      padding: drawerOpen
        ? { top: 40, bottom: 40, left: 40, right: 440 }
        : { top: 40, bottom: 40, left: 40, right: 40 },
      duration: 400,
    });
  }, [drawerOpen, mapLoaded]);

  if (mapError) {
    return (
      <div className="flex h-full w-full items-center justify-center bg-slate-950 text-red-400">
        <p className="max-w-xs text-center text-sm">{mapError}</p>
      </div>
    );
  }

  return (
    <div className="relative h-full w-full overflow-hidden">
      <div ref={containerRef} className="h-full w-full" />

      <AnimatePresence>{!mapLoaded && <MapLoadingOverlay key="loading" />}</AnimatePresence>

      {mapLoaded && <TripOverlay trip={trip} momentCount={trip.moments.length} />}
    </div>
  );
}

function TripOverlay({ trip, momentCount }: { trip: TripWithMoments; momentCount: number }) {
  return (
    <div className="pointer-events-none absolute left-4 top-4 z-10 max-w-[260px]">
      <div className="rounded-2xl border border-white/10 bg-slate-950/80 p-4 backdrop-blur-md">
        <p className="text-[10px] font-semibold uppercase tracking-widest text-amber-400">
          {trip.startDate} → {trip.endDate}
        </p>
        <h2 className="mt-1 font-display text-lg font-bold leading-tight text-white">
          {trip.title}
        </h2>
        {trip.tagline && <p className="mt-1 line-clamp-2 text-xs text-white/50">{trip.tagline}</p>}
        <div className="mt-3 flex gap-3 border-t border-white/10 pt-3">
          <Stat label="Moments" value={momentCount} />
          {trip.countries?.length ? <Stat label="Countries" value={trip.countries.length} /> : null}
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex flex-col">
      <span className="font-display text-xl font-bold text-amber-400">{value}</span>
      <span className="text-[10px] uppercase tracking-widest text-white/40">{label}</span>
    </div>
  );
}
