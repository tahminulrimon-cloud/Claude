import type { MapStyle } from "@/types/sanity";

export const MAPBOX_STYLES: Record<MapStyle, string> = {
  satellite: "mapbox://styles/mapbox/satellite-streets-v12",
  outdoors: "mapbox://styles/mapbox/outdoors-v12",
  dark: "mapbox://styles/mapbox/dark-v11",
  light: "mapbox://styles/mapbox/light-v11",
  streets: "mapbox://styles/mapbox/streets-v12",
};

export const LAYER_IDS = {
  routeSource: "route-source",
  routeGlow: "route-glow",
  routeLine: "route-line",
  routeDash: "route-dash",
} as const;

export const TRANSPORT_ICONS: Record<string, string> = {
  walking: "🚶",
  driving: "🚗",
  train: "🚆",
  cycling: "🚲",
  boat: "⛵",
  flight: "✈️",
  motorbike: "🏍️",
  bus: "🚌",
  cable_car: "🚡",
};

export const WEATHER_ICONS: Record<string, string> = {
  sunny: "☀️",
  partly_cloudy: "⛅",
  overcast: "☁️",
  rainy: "🌧️",
  stormy: "⛈️",
  snowy: "❄️",
  foggy: "🌫️",
  windy: "🌬️",
};
