import type mapboxgl from "mapbox-gl";
import type { SanityMoment } from "@/types/sanity";
import { LAYER_IDS } from "../constants";

export type RouteGeoJSON = GeoJSON.Feature<GeoJSON.LineString>;

export function buildRouteGeoJSON(moments: SanityMoment[]): RouteGeoJSON {
  return {
    type: "Feature",
    properties: {},
    geometry: {
      type: "LineString",
      coordinates: moments.map((m) => [m.coordinates.lng, m.coordinates.lat]),
    },
  };
}

/**
 * Adds three layered route visuals to the map:
 *  1. A soft glow (blurred wide line) drawn first so it sits below
 *  2. A solid route line with a colour gradient
 *  3. An animated travelling dash to indicate direction of travel
 */
export function addRouteToMap(
  map: mapboxgl.Map,
  moments: SanityMoment[],
  routeColor = "#F4A261",
): void {
  const geojson = buildRouteGeoJSON(moments);

  map.addSource(LAYER_IDS.routeSource, {
    type: "geojson",
    data: geojson,
    lineMetrics: true,
  });

  map.addLayer({
    id: LAYER_IDS.routeGlow,
    type: "line",
    source: LAYER_IDS.routeSource,
    layout: { "line-join": "round", "line-cap": "round" },
    paint: {
      "line-color": routeColor,
      "line-width": 12,
      "line-opacity": 0.15,
      "line-blur": 6,
    },
  });

  map.addLayer({
    id: LAYER_IDS.routeLine,
    type: "line",
    source: LAYER_IDS.routeSource,
    layout: { "line-join": "round", "line-cap": "round" },
    paint: {
      "line-gradient": [
        "interpolate",
        ["linear"],
        ["line-progress"],
        0,
        routeColor,
        0.5,
        lightenHex(routeColor, 20),
        1,
        "#ffffff",
      ],
      "line-width": ["interpolate", ["linear"], ["zoom"], 2, 1.5, 6, 2.5, 10, 3.5],
      "line-opacity": 0.9,
    },
  });

  map.addLayer({
    id: LAYER_IDS.routeDash,
    type: "line",
    source: LAYER_IDS.routeSource,
    layout: { "line-join": "round", "line-cap": "butt" },
    paint: {
      "line-color": "#ffffff",
      "line-width": 2,
      "line-opacity": 0.7,
      "line-dasharray": [0, 4, 3],
    },
  });

  animateDash(map);
}

const DASH_SEQUENCE: number[][] = [
  [0, 4, 3], [0.5, 4, 2.5], [1, 4, 2], [1.5, 4, 1.5],
  [2, 4, 1], [2.5, 4, 0.5], [3, 4, 0],
  [0, 0.5, 3.5, 3], [0, 1, 3, 3], [0, 1.5, 2.5, 3],
  [0, 2, 2, 3], [0, 2.5, 1.5, 3], [0, 3, 1, 3],
  [0, 3.5, 0.5, 3], [0, 4, 0, 3],
];

let dashStep = 0;
let timeoutId: ReturnType<typeof setTimeout> | null = null;
let rafId: number | null = null;

function animateDash(map: mapboxgl.Map): void {
  stopDashAnimation();

  function step() {
    if (!map.getLayer(LAYER_IDS.routeDash)) return; // map unmounted

    map.setPaintProperty(LAYER_IDS.routeDash, "line-dasharray", DASH_SEQUENCE[dashStep]);
    dashStep = (dashStep + 1) % DASH_SEQUENCE.length;
    timeoutId = setTimeout(() => {
      rafId = requestAnimationFrame(step);
    }, 80);
  }

  rafId = requestAnimationFrame(step);
}

export function stopDashAnimation(): void {
  if (timeoutId) { clearTimeout(timeoutId); timeoutId = null; }
  if (rafId) { cancelAnimationFrame(rafId); rafId = null; }
}

function lightenHex(hex: string, amount: number): string {
  const num = parseInt(hex.replace("#", ""), 16);
  const r = Math.min(255, (num >> 16) + amount);
  const g = Math.min(255, ((num >> 8) & 0xff) + amount);
  const b = Math.min(255, (num & 0xff) + amount);
  return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, "0")}`;
}
