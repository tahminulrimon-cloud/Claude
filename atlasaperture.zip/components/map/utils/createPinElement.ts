import type { SanityMoment } from "@/types/sanity";
import { cloudinaryThumbUrl } from "@/lib/cloudinaryUrl";
import { TRANSPORT_ICONS } from "../constants";

/**
 * Builds a plain HTMLElement for each Mapbox Marker. Kept as a pure DOM
 * function (no React) so it works inside useEffect without ReactDOM.render.
 */
export function createPinElement(
  moment: SanityMoment,
  index: number,
  totalCount: number,
): HTMLElement {
  const isHighlight = moment.isHighlight;
  const isFirst = index === 0;
  const isLast = index === totalCount - 1;

  const wrapper = document.createElement("div");
  wrapper.className = [
    "pin-wrapper",
    isHighlight ? "pin-wrapper--highlight" : "",
    isFirst ? "pin-wrapper--start" : "",
    isLast ? "pin-wrapper--end" : "",
  ]
    .filter(Boolean)
    .join(" ");
  wrapper.setAttribute("data-moment-id", moment._id);
  wrapper.setAttribute("aria-label", moment.title);
  wrapper.setAttribute("role", "button");
  wrapper.setAttribute("tabindex", "0");

  const thumb = document.createElement("div");
  thumb.className = "pin-thumb";

  const coverMedia = moment.media.find((m) => m.isCover) ?? moment.media[0];
  if (coverMedia?.asset?.url) {
    thumb.style.backgroundImage = `url(${cloudinaryThumbUrl(coverMedia.asset.url, 96)})`;
  } else {
    thumb.style.background = "linear-gradient(135deg, #667eea 0%, #764ba2 100%)";
    const initial = document.createElement("span");
    initial.className = "pin-initial";
    initial.textContent = moment.title.charAt(0).toUpperCase();
    thumb.appendChild(initial);
  }

  if (!isFirst && !isLast) {
    const badge = document.createElement("div");
    badge.className = "pin-badge";
    badge.textContent = String(index + 1);
    thumb.appendChild(badge);
  }

  if (isFirst || isLast || isHighlight) {
    const label = document.createElement("div");
    label.className = "pin-label";
    label.textContent = isFirst ? "Start" : isLast ? "End" : "⭐ Highlight";
    wrapper.appendChild(label);
  }

  if (moment.transportMode && index > 0) {
    const icon = document.createElement("div");
    icon.className = "pin-transport";
    icon.textContent = TRANSPORT_ICONS[moment.transportMode] ?? "📍";
    thumb.appendChild(icon);
  }

  const stem = document.createElement("div");
  stem.className = "pin-stem";

  wrapper.appendChild(thumb);
  wrapper.appendChild(stem);

  return wrapper;
}
