import mapboxgl from "mapbox-gl";
import type { SanityMoment } from "@/types/sanity";

export function fitBoundsToMoments(
  map: mapboxgl.Map,
  moments: SanityMoment[],
  options: mapboxgl.FitBoundsOptions = {},
): void {
  if (!moments.length) return;

  const bounds = moments.reduce(
    (acc, m) => acc.extend([m.coordinates.lng, m.coordinates.lat] as [number, number]),
    new mapboxgl.LngLatBounds(
      [moments[0].coordinates.lng, moments[0].coordinates.lat],
      [moments[0].coordinates.lng, moments[0].coordinates.lat],
    ),
  );

  map.fitBounds(bounds, {
    padding: { top: 80, bottom: 80, left: 80, right: 80 },
    maxZoom: 14,
    duration: 1400,
    ...options,
  });
}
