import { v2 as cloudinary } from "cloudinary";

let configured = false;

// Lazily configured rather than at module top-level: the standalone CLI
// script loads .env.local at runtime, and ESM hoists imports before that
// load call runs — a top-level cloudinary.config() would read undefined
// env vars. Configuring inside each call sidesteps that.
function ensureConfigured() {
  if (configured) return;
  cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
    secure: true,
  });
  configured = true;
}

export interface CloudinaryUploadResult {
  public_id: string;
  secure_url: string;
  width: number;
  height: number;
  format: string;
  bytes: number;
  image_metadata?: Record<string, string>;
}

export async function uploadBufferToCloudinary(
  buffer: Buffer,
  options: { folder: string; publicId?: string },
): Promise<CloudinaryUploadResult> {
  ensureConfigured();
  return new Promise((resolve, reject) => {
    const stream = cloudinary.uploader.upload_stream(
      {
        folder: options.folder,
        public_id: options.publicId,
        resource_type: "image",
        image_metadata: true, // ask Cloudinary for EXIF as a fallback source
        overwrite: false,
      },
      (error, result) => {
        if (error || !result) return reject(error ?? new Error("Cloudinary upload failed"));
        resolve(result as unknown as CloudinaryUploadResult);
      },
    );
    stream.end(buffer);
  });
}
