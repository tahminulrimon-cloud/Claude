/** Cheap blur placeholder using Cloudinary's own transform pipeline. */
export function cloudinaryBlurUrl(url: string): string {
  return url.replace("/upload/", "/upload/e_blur:1000,q_1,w_50/");
}

/** Square crop thumbnail, used for map pin markers. */
export function cloudinaryThumbUrl(url: string, size = 96): string {
  return url.replace("/upload/", `/upload/w_${size},h_${size},c_fill,g_auto/`);
}

/** Resize preserving aspect ratio, used for the lightbox full view. */
export function cloudinaryResizeUrl(url: string, width: number): string {
  return url.replace("/upload/", `/upload/w_${width},c_limit,f_auto,q_auto/`);
}
