import exifr from "exifr";
import type { ExifData } from "@/types/sanity";

export interface ExtractedExif extends ExifData {
  latitude?: number;
  longitude?: number;
  capturedAt?: string; // ISO
}

// ifd0 (camera make/model) can't be disabled in exifr, so it's omitted here.
const EXIF_OPTIONS = {
  gps: true,
  exif: true,
  translateValues: true,
  reviveValues: true,
};

export async function extractExif(buffer: Buffer): Promise<ExtractedExif | null> {
  try {
    const raw = await exifr.parse(buffer, EXIF_OPTIONS);
    if (!raw) return null;

    const result: ExtractedExif = {};

    if (typeof raw.latitude === "number" && typeof raw.longitude === "number") {
      result.latitude = raw.latitude;
      result.longitude = raw.longitude;
    }

    if (raw.Make) result.make = String(raw.Make).trim();
    if (raw.Model) result.model = String(raw.Model).trim();

    if (raw.FocalLength) result.focalLength = `${Math.round(raw.FocalLength)}mm`;
    if (raw.FNumber) result.aperture = raw.FNumber.toFixed(1);
    if (raw.ExposureTime) result.shutterSpeed = formatShutterSpeed(raw.ExposureTime);
    if (raw.ISO) result.iso = raw.ISO;

    const dateSource = raw.DateTimeOriginal ?? raw.CreateDate ?? raw.ModifyDate;
    if (dateSource instanceof Date) {
      result.takenAt = dateSource.toISOString();
      result.capturedAt = dateSource.toISOString();
    }

    return result;
  } catch (err) {
    console.warn("[exif] Failed to parse EXIF:", (err as Error).message);
    return null;
  }
}

function formatShutterSpeed(exposureTime: number): string {
  if (exposureTime >= 1) return `${exposureTime}s`;
  return `1/${Math.round(1 / exposureTime)}`;
}

/** Fallback: pull GPS/EXIF from Cloudinary's returned image_metadata if local parsing found nothing. */
export function extractExifFromCloudinaryMetadata(
  metadata: Record<string, string> | undefined,
): Partial<ExtractedExif> {
  if (!metadata) return {};

  const result: Partial<ExtractedExif> = {};

  const lat = metadata["GPSLatitude"];
  const lng = metadata["GPSLongitude"];
  if (lat && lng) {
    const parsedLat = parseDMSString(lat);
    const parsedLng = parseDMSString(lng);
    if (parsedLat != null) result.latitude = parsedLat;
    if (parsedLng != null) result.longitude = parsedLng;
  }

  if (metadata["Make"]) result.make = metadata["Make"];
  if (metadata["Model"]) result.model = metadata["Model"];

  return result;
}

// Cloudinary returns GPS as `40 deg 42' 46.80" N` — convert to decimal degrees.
function parseDMSString(dms: string): number | null {
  const match = dms.match(/(\d+) deg (\d+)' ([\d.]+)"\s*([NSEW])/);
  if (!match) return null;
  const [, deg, min, sec, dir] = match;
  let decimal = Number(deg) + Number(min) / 60 + Number(sec) / 3600;
  if (dir === "S" || dir === "W") decimal *= -1;
  return decimal;
}
