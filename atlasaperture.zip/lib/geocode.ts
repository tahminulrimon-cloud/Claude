interface ReverseGeocodeResult {
  locationName: string;
  city?: string;
  country?: string;
}

interface MapboxFeature {
  place_name?: string;
  place_type?: string[];
  text?: string;
  context?: { id: string; text: string }[];
}

// In-memory cache keyed to ~111m precision — cheap dedupe for photos
// clustered at the same location within one process run.
const geocodeCache = new Map<string, ReverseGeocodeResult>();
const cacheKey = (lat: number, lng: number) => `${lat.toFixed(3)},${lng.toFixed(3)}`;

export async function reverseGeocode(lat: number, lng: number): Promise<ReverseGeocodeResult> {
  const key = cacheKey(lat, lng);
  const cached = geocodeCache.get(key);
  if (cached) return cached;

  // Use a separate server-side token if your public Mapbox token is
  // URL-restricted to your frontend domain (it usually should be).
  const token = process.env.MAPBOX_SERVER_TOKEN ?? process.env.NEXT_PUBLIC_MAPBOX_TOKEN;
  if (!token) throw new Error("MAPBOX_SERVER_TOKEN is not set");

  const url = new URL(`https://api.mapbox.com/geocoding/v5/mapbox.places/${lng},${lat}.json`);
  url.searchParams.set("access_token", token);
  url.searchParams.set("types", "place,locality,region,country");
  url.searchParams.set("limit", "1");

  const res = await fetch(url.toString());
  if (!res.ok) throw new Error(`Mapbox geocoding failed: ${res.status} ${res.statusText}`);

  const data = await res.json();
  const feature: MapboxFeature | undefined = data.features?.[0];

  const result: ReverseGeocodeResult = {
    locationName: feature?.place_name ?? `${lat.toFixed(4)}, ${lng.toFixed(4)}`,
    city: extractContext(feature, ["place", "locality"]),
    country: extractContext(feature, ["country"]),
  };

  geocodeCache.set(key, result);
  return result;
}

// Mapbox nests broader admin levels (region/country) inside feature.context[]
function extractContext(feature: MapboxFeature | undefined, types: string[]): string | undefined {
  if (!feature) return undefined;
  if (feature.place_type && types.includes(feature.place_type[0])) return feature.text;

  return feature.context?.find((c) => types.some((t) => c.id.startsWith(t)))?.text;
}
