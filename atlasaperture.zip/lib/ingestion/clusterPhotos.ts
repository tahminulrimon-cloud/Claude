export interface ClusterablePhoto {
  latitude: number;
  longitude: number;
  capturedAt: string;
  [key: string]: unknown;
}

export interface PhotoCluster<T extends ClusterablePhoto> {
  photos: T[];
  centroid: { lat: number; lng: number };
  earliestCapturedAt: string;
}

interface ClusterOptions {
  radiusMeters?: number;
  windowMinutes?: number;
}

/**
 * Starts a new cluster whenever a photo falls outside BOTH the distance
 * and time thresholds relative to the current cluster's running centroid.
 */
export function clusterPhotosByProximity<T extends ClusterablePhoto>(
  photos: T[],
  options: ClusterOptions = {},
): PhotoCluster<T>[] {
  const radiusMeters = options.radiusMeters ?? 150;
  const windowMinutes = options.windowMinutes ?? 90;

  const sorted = [...photos].sort(
    (a, b) => new Date(a.capturedAt).getTime() - new Date(b.capturedAt).getTime(),
  );

  const clusters: PhotoCluster<T>[] = [];

  for (const photo of sorted) {
    const current = clusters[clusters.length - 1];

    if (current) {
      const distance = haversineDistance(current.centroid, {
        lat: photo.latitude,
        lng: photo.longitude,
      });
      const timeGapMinutes =
        (new Date(photo.capturedAt).getTime() - new Date(current.earliestCapturedAt).getTime()) /
        60_000;

      if (distance <= radiusMeters && timeGapMinutes <= windowMinutes) {
        current.photos.push(photo);
        current.centroid = recomputeCentroid(current.photos);
        continue;
      }
    }

    clusters.push({
      photos: [photo],
      centroid: { lat: photo.latitude, lng: photo.longitude },
      earliestCapturedAt: photo.capturedAt,
    });
  }

  return clusters;
}

function recomputeCentroid<T extends ClusterablePhoto>(photos: T[]) {
  return {
    lat: photos.reduce((s, p) => s + p.latitude, 0) / photos.length,
    lng: photos.reduce((s, p) => s + p.longitude, 0) / photos.length,
  };
}

function haversineDistance(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number },
): number {
  const R = 6_371_000;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

const toRad = (deg: number) => (deg * Math.PI) / 180;
