import { randomUUID } from "crypto";
import { extractExif, extractExifFromCloudinaryMetadata, type ExtractedExif } from "@/lib/exif";
import { uploadBufferToCloudinary, type CloudinaryUploadResult } from "@/lib/cloudinary";
import { reverseGeocode } from "@/lib/geocode";
import { clusterPhotosByProximity } from "./clusterPhotos";
import { getSanityWriteClient } from "@/sanity/lib/writeClient";

export interface RawPhotoInput {
  buffer: Buffer;
  filename: string;
}

interface ProcessedPhoto {
  filename: string;
  cloudinary: CloudinaryUploadResult;
  exif: ExtractedExif;
  needsManualLocation: boolean;
}

export interface IngestionResult {
  momentsCreated: { draftId: string; title: string; photoCount: number }[];
  needsManualLocation: string[];
  errors: { filename: string; error: string }[];
}

const CLOUDINARY_FOLDER_PREFIX = "atlas-aperture/trips";

/**
 * 1. Extract EXIF (GPS + camera data) from each photo
 * 2. Upload to Cloudinary (always — even photos missing GPS still get stored)
 * 3. Fall back to Cloudinary's own metadata for GPS if exifr found none
 * 4. Cluster photos into Moments by time + distance
 * 5. Reverse-geocode each cluster's centroid
 * 6. Create a DRAFT Sanity `moment` document per cluster
 *
 * Drafts, not published docs: titles, journal entries, transport mode and
 * mood are creative content EXIF can never supply. A human reviews and
 * publishes each draft from Sanity Studio.
 */
export async function processPhotoBatch(
  photos: RawPhotoInput[],
  tripId: string,
  options: { radiusMeters?: number; windowMinutes?: number } = {},
): Promise<IngestionResult> {
  const processed: ProcessedPhoto[] = [];
  const errors: IngestionResult["errors"] = [];

  await Promise.all(
    photos.map(async (photo) => {
      try {
        const exif = (await extractExif(photo.buffer)) ?? {};

        const cloudinaryResult = await uploadBufferToCloudinary(photo.buffer, {
          folder: `${CLOUDINARY_FOLDER_PREFIX}/${tripId}`,
          publicId: sanitisePublicId(photo.filename),
        });

        let finalExif = exif;
        if (exif.latitude == null || exif.longitude == null) {
          finalExif = {
            ...exif,
            ...extractExifFromCloudinaryMetadata(cloudinaryResult.image_metadata),
          };
        }

        processed.push({
          filename: photo.filename,
          cloudinary: cloudinaryResult,
          exif: finalExif,
          needsManualLocation: finalExif.latitude == null || finalExif.longitude == null,
        });
      } catch (err) {
        errors.push({ filename: photo.filename, error: (err as Error).message });
      }
    }),
  );

  const locatable = processed.filter((p) => !p.needsManualLocation);
  const unlocatable = processed.filter((p) => p.needsManualLocation);

  const clusters = clusterPhotosByProximity(
    locatable.map((p) => ({
      ...p,
      latitude: p.exif.latitude!,
      longitude: p.exif.longitude!,
      capturedAt: p.exif.capturedAt ?? new Date().toISOString(),
    })),
    options,
  );

  const momentsCreated: IngestionResult["momentsCreated"] = [];

  for (const cluster of clusters) {
    const geo = await reverseGeocode(cluster.centroid.lat, cluster.centroid.lng);

    const mediaItems = cluster.photos.map((p, i) => ({
      _key: randomUUID(),
      _type: "mediaItem",
      mediaType: "photo" as const,
      isCover: i === 0,
      asset: {
        _type: "cloudinaryImage",
        publicId: p.cloudinary.public_id,
        url: p.cloudinary.secure_url,
        width: p.cloudinary.width,
        height: p.cloudinary.height,
        format: p.cloudinary.format,
        bytes: p.cloudinary.bytes,
      },
      exifData: {
        make: p.exif.make,
        model: p.exif.model,
        focalLength: p.exif.focalLength,
        aperture: p.exif.aperture,
        shutterSpeed: p.exif.shutterSpeed,
        iso: p.exif.iso,
        takenAt: p.exif.takenAt,
      },
    }));

    const title = geo.city ?? geo.locationName.split(",")[0];

    const draft = await getSanityWriteClient().create({
      _id: `drafts.moment-${randomUUID()}`,
      _type: "moment",
      title,
      trip: { _type: "reference", _ref: tripId },
      capturedAt: cluster.earliestCapturedAt,
      coordinates: { lat: cluster.centroid.lat, lng: cluster.centroid.lng },
      locationName: geo.locationName,
      city: geo.city,
      country: geo.country,
      media: mediaItems,
      isHighlight: false,
    });

    momentsCreated.push({ draftId: draft._id, title, photoCount: cluster.photos.length });
  }

  return {
    momentsCreated,
    needsManualLocation: unlocatable.map((p) => p.filename),
    errors,
  };
}

function sanitisePublicId(filename: string): string {
  return filename
    .replace(/\.[^/.]+$/, "")
    .replace(/[^a-zA-Z0-9_-]/g, "-")
    .toLowerCase();
}
