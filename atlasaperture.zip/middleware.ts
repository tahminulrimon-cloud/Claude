import { NextRequest, NextResponse } from "next/server";

// Lightweight shared-secret Basic Auth for the admin uploader and its API
// route. Proportionate for a one-or-two-person admin tool — swap for a real
// auth provider (Clerk, NextAuth) if more editors join later.
export function middleware(req: NextRequest) {
  const basicAuth = req.headers.get("authorization");

  if (basicAuth) {
    const [, encoded] = basicAuth.split(" ");
    const [user, pwd] = atob(encoded).split(":");

    if (user === process.env.ADMIN_USER && pwd === process.env.ADMIN_PASSWORD) {
      return NextResponse.next();
    }
  }

  return new NextResponse("Authentication required", {
    status: 401,
    headers: { "WWW-Authenticate": 'Basic realm="Atlas & Aperture Admin"' },
  });
}

export const config = {
  matcher: ["/admin/:path*", "/api/moments/ingest"],
};
