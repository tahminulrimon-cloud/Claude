import { groq } from "next-sanity";

// ── Fragments ──────────────────────────────────────────────────────────────

const coordinatesFields = groq`
  coordinates { lat, lng }
`;

const weatherFields = groq`
  weather { condition, temperatureCelsius, humidity }
`;

const mediaFields = groq`
  media[] {
    _key,
    mediaType,
    caption,
    isCover,
    altText,
    asset {
      publicId,
      url,
      width,
      height,
      format,
      bytes
    },
    exifData
  }
`;

const momentFields = groq`
  _id,
  _type,
  title,
  "slug": slug.current,
  capturedAt,
  ${coordinatesFields},
  locationName,
  country,
  city,
  ${mediaFields},
  journalEntry,
  ${weatherFields},
  transportMode,
  mood,
  tags,
  isHighlight
`;

// ── Queries ────────────────────────────────────────────────────────────────

/** All published trips — powers the homepage list. */
export const ALL_TRIPS_QUERY = groq`
  *[_type == "trip" && isPublished == true] | order(startDate desc) {
    _id,
    title,
    "slug": slug.current,
    tagline,
    startDate,
    endDate,
    countries,
    tags,
    mapStyle,
    routeColor,
    coverImage,
    "momentCount": count(*[_type == "moment" && trip._ref == ^._id])
  }
`;

/** A single trip and ALL its moments, ordered chronologically — powers the map page. */
export const TRIP_WITH_MOMENTS_QUERY = groq`
  *[_type == "trip" && slug.current == $slug && isPublished == true][0] {
    _id,
    title,
    "slug": slug.current,
    tagline,
    description,
    startDate,
    endDate,
    countries,
    tags,
    mapStyle,
    routeColor,
    coverImage,
    "moments": *[_type == "moment" && trip._ref == ^._id]
      | order(capturedAt asc) {
        ${momentFields}
      }
  }
`;

/** A single Moment by ID — used for deep-linking directly to a pin. */
export const MOMENT_BY_ID_QUERY = groq`
  *[_type == "moment" && _id == $id][0] {
    ${momentFields},
    "trip": trip-> {
      _id,
      title,
      "slug": slug.current,
      routeColor,
      mapStyle
    }
  }
`;

/** All Moments tagged as highlights across every trip. */
export const HIGHLIGHT_MOMENTS_QUERY = groq`
  *[_type == "moment" && isHighlight == true] | order(capturedAt desc) {
    ${momentFields},
    "tripTitle": trip->title,
    "tripSlug": trip->slug.current,
  }
`;

/** Moments within a bounding box — for viewport-aware map loading. */
export const MOMENTS_IN_BOUNDS_QUERY = groq`
  *[
    _type == "moment"
    && coordinates.lat >= $minLat
    && coordinates.lat <= $maxLat
    && coordinates.lng >= $minLng
    && coordinates.lng <= $maxLng
    && ($tripId == null || trip._ref == $tripId)
  ] | order(capturedAt asc) {
    ${momentFields}
  }
`;
