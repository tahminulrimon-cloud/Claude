import { createClient } from "next-sanity";

let client: ReturnType<typeof createClient> | null = null;

/**
 * Lazily constructed so this module can be imported before environment
 * variables are loaded — the standalone CLI script (scripts/import-photos.ts)
 * loads .env.local at runtime rather than via Next.js's build-time env
 * pipeline, and ESM hoists imports ahead of that load call.
 *
 * NEVER import this into a client component — it carries a write token.
 */
export function getSanityWriteClient() {
  if (client) return client;

  const token = process.env.SANITY_API_WRITE_TOKEN;
  if (!token) {
    throw new Error(
      "SANITY_API_WRITE_TOKEN is not set. Create one with Editor access in manage.sanity.io.",
    );
  }

  client = createClient({
    projectId: process.env.NEXT_PUBLIC_SANITY_PROJECT_ID!,
    dataset: process.env.NEXT_PUBLIC_SANITY_DATASET ?? "production",
    apiVersion: "2024-01-01",
    token,
    useCdn: false,
  });

  return client;
}
