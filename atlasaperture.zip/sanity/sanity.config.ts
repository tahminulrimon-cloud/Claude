import { defineConfig } from "sanity";
import { structureTool } from "sanity/structure";
import { visionTool } from "@sanity/vision";
import { schemaTypes } from "./schemas";

export default defineConfig({
  name: "atlas-aperture",
  title: "Atlas & Aperture",
  projectId: process.env.NEXT_PUBLIC_SANITY_PROJECT_ID ?? "",
  dataset: process.env.NEXT_PUBLIC_SANITY_DATASET ?? "production",
  basePath: "/studio",
  plugins: [
    structureTool({
      structure: (S) =>
        S.list()
          .title("Atlas & Aperture")
          .items([
            S.listItem()
              .title("Trips")
              .schemaType("trip")
              .child(
                S.documentTypeList("trip")
                  .title("All Trips")
                  .child((tripId) =>
                    S.list()
                      .title("Trip")
                      .items([
                        S.documentListItem().id(tripId).schemaType("trip").title("Trip Info"),
                        S.listItem()
                          .title("Moments")
                          .child(
                            S.documentTypeList("moment")
                              .title("Moments")
                              .filter('_type == "moment" && trip._ref == $tripId')
                              .params({ tripId })
                              .defaultOrdering([{ field: "capturedAt", direction: "asc" }]),
                          ),
                      ]),
                  ),
              ),
            S.divider(),
            S.documentTypeListItem("moment").title("All Moments"),
          ]),
    }),
    visionTool(),
  ],
  schema: { types: schemaTypes },
});
