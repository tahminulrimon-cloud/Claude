import { tripSchema } from "./trip";
import { momentSchema } from "./moment";
import { coordinatesSchema } from "./objects/coordinates";
import { weatherSchema } from "./objects/weather";
import { mediaItemSchema } from "./objects/mediaItem";
import { cloudinaryImageSchema } from "./objects/cloudinaryImage";

// Object schemas must be registered before the documents that reference them
export const schemaTypes = [
  coordinatesSchema,
  weatherSchema,
  cloudinaryImageSchema,
  mediaItemSchema,
  tripSchema,
  momentSchema,
];
