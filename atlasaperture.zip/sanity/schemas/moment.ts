import { defineType, defineField, defineArrayMember } from "sanity";
import { ImagesIcon } from "@sanity/icons";

const TRANSPORT_MODES = [
  { title: "🚶 Walking", value: "walking" },
  { title: "🚗 Driving", value: "driving" },
  { title: "🚆 Train", value: "train" },
  { title: "🚲 Cycling", value: "cycling" },
  { title: "⛵ Boat", value: "boat" },
  { title: "✈️ Flight", value: "flight" },
  { title: "🏍️ Motorbike", value: "motorbike" },
  { title: "🚌 Bus", value: "bus" },
  { title: "🚡 Cable Car", value: "cable_car" },
];

export const momentSchema = defineType({
  name: "moment",
  title: "Moment",
  type: "document",
  icon: ImagesIcon,
  fields: [
    defineField({
      name: "title",
      title: "Location Name",
      type: "string",
      description: 'Short display name, e.g. "Fushimi Inari Shrine".',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: "slug",
      title: "Slug",
      type: "slug",
      options: { source: "title", maxLength: 96 },
    }),
    defineField({
      name: "trip",
      title: "Trip",
      type: "reference",
      to: [{ type: "trip" }],
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: "capturedAt",
      title: "Date & Time",
      type: "datetime",
      description: "When this moment happened (used for chronological ordering).",
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: "coordinates",
      title: "GPS Coordinates",
      type: "coordinates",
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: "locationName",
      title: "Full Location Name",
      type: "string",
      description: "Human-readable address (auto-filled via reverse geocoding).",
    }),
    defineField({ name: "country", title: "Country", type: "string" }),
    defineField({ name: "city", title: "City / Region", type: "string" }),
    defineField({
      name: "media",
      title: "Photos & Videos",
      type: "array",
      of: [defineArrayMember({ type: "mediaItem" })],
      description: "First item marked as cover will be used as the pin thumbnail.",
      validation: (Rule) => Rule.required().min(1),
    }),
    defineField({
      name: "journalEntry",
      title: "Journal Entry",
      type: "array",
      of: [
        defineArrayMember({
          type: "block",
          styles: [
            { title: "Normal", value: "normal" },
            { title: "Heading", value: "h3" },
            { title: "Quote", value: "blockquote" },
          ],
          marks: {
            decorators: [
              { title: "Strong", value: "strong" },
              { title: "Emphasis", value: "em" },
              { title: "Underline", value: "underline" },
            ],
          },
        }),
      ],
    }),
    defineField({ name: "weather", title: "Weather", type: "weather" }),
    defineField({
      name: "transportMode",
      title: "How did you arrive?",
      type: "string",
      options: { list: TRANSPORT_MODES },
    }),
    defineField({
      name: "mood",
      title: "Mood",
      type: "string",
      options: {
        list: [
          { title: "😄 Joyful", value: "joyful" },
          { title: "😌 Peaceful", value: "peaceful" },
          { title: "🤩 In Awe", value: "in_awe" },
          { title: "😴 Tired", value: "tired" },
          { title: "😤 Frustrated", value: "frustrated" },
          { title: "🥹 Emotional", value: "emotional" },
        ],
      },
    }),
    defineField({
      name: "tags",
      title: "Tags",
      type: "array",
      of: [defineArrayMember({ type: "string" })],
      options: { layout: "tags" },
    }),
    defineField({
      name: "isHighlight",
      title: "Trip Highlight?",
      type: "boolean",
      description: "Mark as a highlight to display a special golden pin on the map.",
      initialValue: false,
    }),
  ],
  orderings: [
    {
      title: "Chronological",
      name: "capturedAtAsc",
      by: [{ field: "capturedAt", direction: "asc" }],
    },
  ],
  preview: {
    select: {
      title: "title",
      trip: "trip.title",
      date: "capturedAt",
      media: "media.0.asset.url",
      highlight: "isHighlight",
    },
    prepare: ({ title, trip, date, media, highlight }) => ({
      title: `${highlight ? "⭐ " : ""}${title}`,
      subtitle: `${trip ?? "—"} · ${date ? new Date(date).toLocaleDateString() : ""}`,
      imageUrl: media,
    }),
  },
});
