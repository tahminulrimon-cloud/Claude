import { defineType, defineField } from "sanity";
import { ImageIcon } from "@sanity/icons";

export const cloudinaryImageSchema = defineType({
  name: "cloudinaryImage",
  title: "Cloudinary Image",
  type: "object",
  icon: ImageIcon,
  fields: [
    defineField({
      name: "publicId",
      title: "Public ID",
      type: "string",
      readOnly: true,
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: "url",
      title: "Secure URL",
      type: "url",
      readOnly: true,
      validation: (Rule) => Rule.required(),
    }),
    defineField({ name: "width", title: "Width", type: "number", readOnly: true }),
    defineField({ name: "height", title: "Height", type: "number", readOnly: true }),
    defineField({ name: "format", title: "Format", type: "string", readOnly: true }),
    defineField({ name: "bytes", title: "File Size (bytes)", type: "number", readOnly: true }),
  ],
  preview: {
    select: { publicId: "publicId", url: "url" },
    prepare: ({ publicId, url }) => ({ title: publicId, subtitle: url, imageUrl: url }),
  },
});
