import { defineType, defineField } from "sanity";
import { PinIcon } from "@sanity/icons";

export const coordinatesSchema = defineType({
  name: "coordinates",
  title: "GPS Coordinates",
  type: "object",
  icon: PinIcon,
  fields: [
    defineField({
      name: "lat",
      title: "Latitude",
      type: "number",
      validation: (Rule) =>
        Rule.required().min(-90).max(90).error("Must be between -90 and 90"),
    }),
    defineField({
      name: "lng",
      title: "Longitude",
      type: "number",
      validation: (Rule) =>
        Rule.required().min(-180).max(180).error("Must be between -180 and 180"),
    }),
  ],
  preview: {
    select: { lat: "lat", lng: "lng" },
    prepare: ({ lat, lng }) => ({
      title: lat && lng ? `${lat.toFixed(4)}, ${lng.toFixed(4)}` : "No coordinates",
    }),
  },
});
