import { defineType, defineField } from "sanity";
import { ImageIcon } from "@sanity/icons";

export const mediaItemSchema = defineType({
  name: "mediaItem",
  title: "Media Item",
  type: "object",
  icon: ImageIcon,
  fields: [
    defineField({
      name: "asset",
      title: "Image",
      type: "cloudinaryImage",
    }),
    defineField({
      name: "altText",
      title: "Alt Text",
      type: "string",
      description: "Describe the image for accessibility & SEO.",
    }),
    defineField({
      name: "mediaType",
      title: "Media Type",
      type: "string",
      initialValue: "photo",
      options: {
        layout: "radio",
        list: [
          { title: "📷 Photo", value: "photo" },
          { title: "🎥 Video", value: "video" },
          { title: "🎞️ GIF", value: "gif" },
        ],
      },
    }),
    defineField({
      name: "caption",
      title: "Caption",
      type: "string",
    }),
    defineField({
      name: "isCover",
      title: "Use as cover for this Moment?",
      type: "boolean",
      initialValue: false,
    }),
    defineField({
      name: "exifData",
      title: "EXIF Data (auto-populated)",
      type: "object",
      readOnly: true,
      fields: [
        defineField({ name: "make", title: "Camera Make", type: "string" }),
        defineField({ name: "model", title: "Camera Model", type: "string" }),
        defineField({ name: "focalLength", title: "Focal Length", type: "string" }),
        defineField({ name: "aperture", title: "Aperture (f/)", type: "string" }),
        defineField({ name: "shutterSpeed", title: "Shutter Speed", type: "string" }),
        defineField({ name: "iso", title: "ISO", type: "number" }),
        defineField({ name: "takenAt", title: "Taken At", type: "datetime" }),
      ],
    }),
  ],
  preview: {
    select: { url: "asset.url", caption: "caption", mediaType: "mediaType" },
    prepare: ({ url, caption, mediaType }) => ({
      title: caption ?? "Untitled",
      subtitle: mediaType,
      imageUrl: url,
    }),
  },
});
