import { defineType, defineField } from "sanity";

export const weatherSchema = defineType({
  name: "weather",
  title: "Weather",
  type: "object",
  fields: [
    defineField({
      name: "condition",
      title: "Condition",
      type: "string",
      options: {
        list: [
          { title: "☀️  Sunny", value: "sunny" },
          { title: "⛅  Partly Cloudy", value: "partly_cloudy" },
          { title: "☁️  Overcast", value: "overcast" },
          { title: "🌧️  Rainy", value: "rainy" },
          { title: "⛈️  Stormy", value: "stormy" },
          { title: "❄️  Snowy", value: "snowy" },
          { title: "🌫️  Foggy", value: "foggy" },
          { title: "🌬️  Windy", value: "windy" },
        ],
      },
    }),
    defineField({
      name: "temperatureCelsius",
      title: "Temperature (°C)",
      type: "number",
      validation: (Rule) => Rule.min(-60).max(60),
    }),
    defineField({
      name: "humidity",
      title: "Humidity (%)",
      type: "number",
      validation: (Rule) => Rule.min(0).max(100),
    }),
  ],
  preview: {
    select: { condition: "condition", temp: "temperatureCelsius" },
    prepare: ({ condition, temp }) => ({
      title: `${condition ?? "Unknown"} · ${temp != null ? `${temp}°C` : "—"}`,
    }),
  },
});
