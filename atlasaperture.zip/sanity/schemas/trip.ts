import { defineType, defineField, defineArrayMember } from "sanity";
import { EarthGlobeIcon } from "@sanity/icons";

export const tripSchema = defineType({
  name: "trip",
  title: "Trip",
  type: "document",
  icon: EarthGlobeIcon,
  fields: [
    defineField({
      name: "title",
      title: "Trip Title",
      type: "string",
      description: 'e.g. "Japan Spring 2024" or "Patagonia Roadtrip"',
      validation: (Rule) => Rule.required().min(3).max(80),
    }),
    defineField({
      name: "slug",
      title: "Slug",
      type: "slug",
      options: {
        source: "title",
        maxLength: 96,
        isUnique: (value, context) => context.defaultIsUnique(value, context),
      },
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: "tagline",
      title: "Tagline",
      type: "string",
      description: "One-line description shown on the map overlay.",
    }),
    defineField({
      name: "description",
      title: "Full Description",
      type: "array",
      of: [defineArrayMember({ type: "block" })],
    }),
    defineField({
      name: "coverImage",
      title: "Cover Image",
      type: "cloudinaryImage",
    }),
    defineField({
      name: "startDate",
      title: "Start Date",
      type: "date",
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: "endDate",
      title: "End Date",
      type: "date",
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: "countries",
      title: "Countries Visited",
      type: "array",
      of: [defineArrayMember({ type: "string" })],
      options: { layout: "tags" },
    }),
    defineField({
      name: "tags",
      title: "Tags",
      type: "array",
      of: [defineArrayMember({ type: "string" })],
      options: { layout: "tags" },
      description: 'e.g. "backpacking", "solo", "food", "hiking"',
    }),
    defineField({
      name: "isPublished",
      title: "Published",
      type: "boolean",
      initialValue: false,
    }),
    defineField({
      name: "mapStyle",
      title: "Map Style",
      type: "string",
      options: {
        list: [
          { title: "Satellite", value: "satellite" },
          { title: "Outdoors", value: "outdoors" },
          { title: "Dark", value: "dark" },
          { title: "Light", value: "light" },
          { title: "Streets", value: "streets" },
        ],
      },
      initialValue: "outdoors",
    }),
    defineField({
      name: "routeColor",
      title: "Route Line Color (hex)",
      type: "string",
      initialValue: "#F4A261",
      description: "Hex colour for the animated route line connecting pins.",
    }),
  ],
  preview: {
    select: {
      title: "title",
      startDate: "startDate",
      endDate: "endDate",
      media: "coverImage.url",
    },
    prepare: ({ title, startDate, endDate, media }) => ({
      title,
      subtitle: startDate && endDate ? `${startDate} → ${endDate}` : "Dates not set",
      imageUrl: media,
    }),
  },
  orderings: [
    {
      title: "Start Date, Newest First",
      name: "startDateDesc",
      by: [{ field: "startDate", direction: "desc" }],
    },
  ],
});
