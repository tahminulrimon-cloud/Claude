#!/usr/bin/env tsx
/**
 * Usage:
 *   npm run import-photos -- --trip=<sanityTripId> --dir=./photos-to-import
 *
 * Reuses the exact pipeline the /api/moments/ingest route uses. Intended
 * for a one-off "dump the whole camera roll" import rather than the
 * drag-and-drop admin UI (which caps at 60 files per request).
 */
import { readdir, readFile } from "fs/promises";
import { join, extname } from "path";
import { config } from "dotenv";

config({ path: ".env.local" }); // must run before any import that reads env vars lazily

import { processPhotoBatch, type RawPhotoInput } from "../lib/ingestion/processPhotoBatch";

const IMAGE_EXTENSIONS = new Set([".jpg", ".jpeg", ".png", ".heic", ".webp"]);

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (!args.trip || !args.dir) {
    console.error("Usage: npm run import-photos -- --trip=<tripId> --dir=<folder>");
    process.exit(1);
  }

  console.log(`\n📸  Scanning ${args.dir} …`);
  const filenames = (await readdir(args.dir)).filter((f) =>
    IMAGE_EXTENSIONS.has(extname(f).toLowerCase()),
  );
  if (!filenames.length) {
    console.error("No supported image files found.");
    process.exit(1);
  }
  console.log(`   Found ${filenames.length} images. Reading + extracting EXIF…\n`);

  const photos: RawPhotoInput[] = await Promise.all(
    filenames.map(async (filename) => ({
      filename,
      buffer: await readFile(join(args.dir!, filename)),
    })),
  );

  const result = await processPhotoBatch(photos, args.trip, {
    radiusMeters: args.radius ? Number(args.radius) : undefined,
    windowMinutes: args.window ? Number(args.window) : undefined,
  });

  console.log(`✅  Created ${result.momentsCreated.length} draft Moment(s):\n`);
  result.momentsCreated.forEach((m) =>
    console.log(
      `   • ${m.title}  (${m.photoCount} photo${m.photoCount === 1 ? "" : "s"})  → ${m.draftId}`,
    ),
  );

  if (result.needsManualLocation.length) {
    console.log(`\n⚠️   ${result.needsManualLocation.length} photo(s) had no GPS data and were skipped:`);
    result.needsManualLocation.forEach((f) => console.log(`   • ${f}`));
    console.log("   Add coordinates manually in Sanity Studio, or re-run with geotagged copies.");
  }

  if (result.errors.length) {
    console.log(`\n❌  ${result.errors.length} error(s):`);
    result.errors.forEach((e) => console.log(`   • ${e.filename}: ${e.error}`));
  }

  console.log("\n👉  Review drafts in Sanity Studio before publishing.\n");
}

function parseArgs(argv: string[]): Record<string, string | undefined> {
  const out: Record<string, string | undefined> = {};
  for (const arg of argv) {
    const match = arg.match(/^--([^=]+)=(.*)$/);
    if (match) out[match[1]] = match[2];
  }
  return out;
}

main().catch((err) => {
  console.error("\n💥  Import failed:", err);
  process.exit(1);
});
