import type { PortableTextBlock } from "sanity";

export type WeatherCondition =
  | "sunny" | "partly_cloudy" | "overcast"
  | "rainy" | "stormy" | "snowy" | "foggy" | "windy";

export type TransportMode =
  | "walking" | "driving" | "train" | "cycling"
  | "boat" | "flight" | "motorbike" | "bus" | "cable_car";

export type MapStyle = "satellite" | "outdoors" | "dark" | "light" | "streets";

export interface Coordinates {
  lat: number;
  lng: number;
}

export interface Weather {
  condition: WeatherCondition;
  temperatureCelsius: number;
  humidity?: number;
}

export interface ExifData {
  make?: string;
  model?: string;
  focalLength?: string;
  aperture?: string;
  shutterSpeed?: string;
  iso?: number;
  takenAt?: string;
}

export interface CloudinaryAsset {
  publicId: string;
  url: string;
  width?: number;
  height?: number;
  format?: string;
  bytes?: number;
}

export interface MediaItem {
  _key: string;
  asset: CloudinaryAsset;
  mediaType: "photo" | "video" | "gif";
  caption?: string;
  altText?: string;
  isCover: boolean;
  exifData?: ExifData;
}

export interface SanityTrip {
  _id: string;
  _type: "trip";
  title: string;
  slug: string;
  tagline?: string;
  description?: PortableTextBlock[];
  coverImage?: CloudinaryAsset;
  startDate: string;
  endDate: string;
  countries?: string[];
  tags?: string[];
  isPublished: boolean;
  mapStyle?: MapStyle;
  routeColor?: string;
}

export interface SanityMoment {
  _id: string;
  _type: "moment";
  title: string;
  slug: string;
  capturedAt: string;
  coordinates: Coordinates;
  locationName?: string;
  country?: string;
  city?: string;
  media: MediaItem[];
  journalEntry?: PortableTextBlock[];
  weather?: Weather;
  transportMode?: TransportMode;
  mood?: string;
  tags?: string[];
  isHighlight: boolean;
}

export interface TripWithMoments extends SanityTrip {
  moments: SanityMoment[];
}
